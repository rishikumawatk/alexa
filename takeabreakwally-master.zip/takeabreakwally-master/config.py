LTM_DATA_TABLE = "ltm_data"
LAST_TIME_MOVED = "last_time_moved"

#TODO CONFIGURE db path
DB_PATH = r"/home/pi/tribehacks/ltm_db.json"

#TODO Configure Real Server ip and port
HOST = "127.0.0.1"
PORT = 8000
UTF_FORMAT = "UTF-8"
